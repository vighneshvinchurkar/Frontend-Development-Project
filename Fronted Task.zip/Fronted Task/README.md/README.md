# Frontend Development Internship Project

## Features

- HTML5 Structure
- Inline CSS
- Responsive Design
- Bootstrap Components
- Interactive Button
- API Integration
- Form Validation
- SCSS Styling

## Technologies

- HTML
- CSS
- Bootstrap 5
- JavaScript
- Fetch API
- SCSS